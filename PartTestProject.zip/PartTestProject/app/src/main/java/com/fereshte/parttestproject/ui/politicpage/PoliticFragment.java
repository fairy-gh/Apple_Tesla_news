package com.fereshte.parttestproject.ui.politicpage;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.fereshte.parttestproject.R;
import com.fereshte.parttestproject.databinding.FragmentHomeBinding;
import com.fereshte.parttestproject.databinding.FragmentPoliticBinding;
import com.fereshte.parttestproject.ui.newspage.NewsFragment;

public class PoliticFragment extends Fragment {

    private FragmentPoliticBinding mBinding;

    public static Fragment getInstance(){
        return new PoliticFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentPoliticBinding.inflate(inflater);
        return mBinding.getRoot();    }
}