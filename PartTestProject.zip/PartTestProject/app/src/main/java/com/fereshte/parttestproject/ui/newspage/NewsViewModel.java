package com.fereshte.parttestproject.ui.newspage;

import android.app.Application;
import android.util.Log;
import com.fereshte.parttestproject.R;
import com.fereshte.parttestproject.data.local.model.NewsContent;
import com.fereshte.parttestproject.data.local.model.NewsModel;
import com.fereshte.parttestproject.data.repository.NewsRepository;
import java.util.ArrayList;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsViewModel extends AndroidViewModel {

    private final NewsRepository repository;
    private final MutableLiveData<List<NewsModel>> newsList = new MutableLiveData<>();

    public NewsViewModel(@NonNull Application application) {
        super(application);
        repository = new NewsRepository(application);
    }

    public LiveData<List<NewsModel>> getNewsList() {
        return newsList;
    }

    public void setNewsList(List<NewsModel> newsList) {
        this.newsList.setValue(newsList);
    }

    public void getAllNews() {
        setNewsList(getNewsFromServer());
    }

    private List<NewsModel> getNewsFromServer(){

        List<NewsModel> list = new ArrayList<>();
        Call<NewsContent> call =
                repository.getApiServiceData("apple", "2022-01-18",
                        "2022-01-18", "popularity",
                        getApplication().getResources().getString(R.string.api_key));

        call.enqueue(new Callback<NewsContent>() {
            @Override
            public void onResponse(@NonNull Call<NewsContent> call, @NonNull Response<NewsContent> response) {
                if(response.body() != null){
                    list.addAll(response.body().getArticles());
                    Log.e("newsTitle->", response.body().getArticles().get(0).getTitle());
                }
            }

            @Override
            public void onFailure(Call<NewsContent> call, Throwable t) {
                Log.e("error", t.getMessage());
            }


        });
        return list;
    }

}
