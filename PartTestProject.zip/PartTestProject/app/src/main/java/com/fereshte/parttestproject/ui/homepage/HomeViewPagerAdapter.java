package com.fereshte.parttestproject.ui.homepage;

import com.fereshte.parttestproject.ui.newspage.NewsFragment;
import com.fereshte.parttestproject.ui.politicpage.PoliticFragment;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class HomeViewPagerAdapter extends FragmentStateAdapter {

    private final int tabNumbers = 2;

    public HomeViewPagerAdapter(@NonNull Fragment fragment) {
        super(fragment);
    }

    @NonNull
    @Override
    public Fragment createFragment(int i) {
        return NewsFragment.getInstance(i);
    }

    @Override
    public int getItemCount() {
        return tabNumbers;
    }
}
