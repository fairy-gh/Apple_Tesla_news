package com.fereshte.parttestproject.ui.newspage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.fereshte.parttestproject.data.local.model.NewsModel;
import com.fereshte.parttestproject.databinding.ItemNewsBinding;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

    private Context context;
    private List<NewsModel> list;

    public NewsAdapter(Context context, List<NewsModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemNewsBinding binding = ItemNewsBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.ViewHolder holder, int position) {
        holder.itemBinding.setNews(list.get(position));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ItemNewsBinding itemBinding;
        public ViewHolder(ItemNewsBinding binding) {
            super(binding.getRoot());
            this.itemBinding = binding;
        }
    }

}
