package com.fereshte.parttestproject.data.local.model;

import android.widget.ImageView;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.picasso.Picasso;

import androidx.databinding.BindingAdapter;

public class NewsModel {
    @SerializedName("title")
    @Expose
    private String title;

//    @SerializedName("urlToImage")
//    @Expose
//    private String urlToImage;
//
//    @SerializedName("publishedAt")
//    @Expose
//    private String publishedAt;

    public NewsModel(String title, String urlToImage, String publishedAt) {
        this.title = title;
//        this.urlToImage = urlToImage;
//        this.publishedAt = publishedAt;
    }

    @BindingAdapter({"android:imageView"})
    public static void loadNewsImg(ImageView imageView, String imgUrl) {
        Picasso.get().load(imgUrl).into(imageView);
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

//    public String getDescription() {
//        return description;
//    }
//    public void setDescription(String description) {
//        this.description = description;
//    }
//
//    public String getAuthor() {
//        return author;
//    }
//
//    public void setAuthor(String author) {
//        this.author = author;
//    }

//    public String getUrlToImage() {
//        return urlToImage;
//    }
//
//    public void setUrlToImage(String urlToImage) {
//        this.urlToImage = urlToImage;
//    }
//
//    public String getPublishedAt() {
//        return publishedAt;
//    }
//
//    public void setPublishedAt(String publishedAt) {
//        this.publishedAt = publishedAt;
//    }
}
