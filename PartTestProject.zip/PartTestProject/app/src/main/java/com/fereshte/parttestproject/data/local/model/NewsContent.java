package com.fereshte.parttestproject.data.local.model;

import java.util.List;

public class NewsContent {

    private List<NewsModel> articles;

    public NewsContent(List<NewsModel> articles) {
        this.articles = articles;
    }

    public List<NewsModel> getArticles() {
        return articles;
    }

    public void setArticles(List<NewsModel> articles) {
        this.articles = articles;
    }
}
