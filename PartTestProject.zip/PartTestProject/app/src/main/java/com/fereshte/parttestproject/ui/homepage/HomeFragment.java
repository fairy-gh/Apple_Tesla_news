package com.fereshte.parttestproject.ui.homepage;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fereshte.parttestproject.R;
import com.fereshte.parttestproject.databinding.FragmentHomeBinding;
import com.google.android.material.tabs.TabLayoutMediator;

public class HomeFragment extends Fragment {

   private FragmentHomeBinding mBinding;
   private HomeViewModel homeViewModel;
   private HomeViewPagerAdapter homeAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentHomeBinding.inflate(inflater);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init();
    }

    private void init() {
        homeViewModel = new ViewModelProvider(requireActivity()).get(HomeViewModel.class);
        setUpViewPager();
    }

    private void setUpViewPager() {
        homeAdapter = new HomeViewPagerAdapter(this);
        mBinding.homeViewPager2.setAdapter(homeAdapter);
        new TabLayoutMediator(mBinding.homeTabs, mBinding.homeViewPager2, (tab, position) -> {
            if(position == 0)
                tab.setText("News");
                else tab.setText("Politics");
        }).attach();
    }
}