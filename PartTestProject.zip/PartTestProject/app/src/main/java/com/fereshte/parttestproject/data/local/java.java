package com.fereshte.parttestproject.data.local;

public class java {
}
