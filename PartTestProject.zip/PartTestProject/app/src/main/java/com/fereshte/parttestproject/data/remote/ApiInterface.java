package com.fereshte.parttestproject.data.remote;

import com.fereshte.parttestproject.data.local.model.NewsContent;
import com.fereshte.parttestproject.data.local.model.NewsModel;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("everything")
    Call<NewsContent> getNews(@Query("q") String company,
                                    @Query("from") String from,
                                    @Query("to") String to,
                                    @Query("sortBy") String sortBy,
                                    @Query("apiKey") String apiKey);

}
