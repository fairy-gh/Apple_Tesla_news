package com.fereshte.parttestproject.ui.newspage;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.fereshte.parttestproject.databinding.FragmentNewsBinding;

public class NewsFragment extends Fragment {

    private FragmentNewsBinding mBinding;
    private NewsViewModel newsViewModel;
    private Boolean isAllNewsSet = true;

    public static Fragment getInstance(int position) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        args.putInt("position", position);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            if (getArguments().getInt("position") == 0) {
                Log.e("position 0 -> ", "tab 1");
                isAllNewsSet = true;
            } else {
                Log.e("position 1 -> ", "tab 2");
                isAllNewsSet = false;
            }
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentNewsBinding.inflate(inflater);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init();
    }

    private void init() {
        newsViewModel = new ViewModelProvider(this).get(NewsViewModel.class);
        if(isAllNewsSet)
            newsViewModel.getAllNews();
        observeRecyclerView();
    }

    private void observeRecyclerView() {
        newsViewModel.getNewsList().observe(requireActivity(),
                news -> mBinding.newsRcv.setAdapter(new NewsAdapter(requireActivity(), news)));
    }

}