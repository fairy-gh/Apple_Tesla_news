package com.fereshte.parttestproject.data.repository;

import android.content.Context;

import com.fereshte.parttestproject.data.local.model.NewsContent;
import com.fereshte.parttestproject.data.local.model.NewsModel;
import com.fereshte.parttestproject.data.remote.ApiInterface;
import com.fereshte.parttestproject.data.remote.ApiService;

import java.util.List;

import retrofit2.Call;

public class NewsRepository {

    private final Context context;
    private String apiKey = "ee13ce3ae166446ab05bcea438073664";
    public NewsRepository(Context context) {
        this.context = context;
    }

    public Call<NewsContent> getApiServiceData(String company, String from, String to, String sortBy, String apiKey){
        return ApiService.getInstance(context).create(ApiInterface.class).getNews(company, from, to, sortBy, apiKey);
    }
}
